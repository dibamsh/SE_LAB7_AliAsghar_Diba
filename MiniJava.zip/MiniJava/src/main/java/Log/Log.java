package Log;

/**
 * Created by mohammad hosein on 6/29/2015.
 */

public class Log {
    public static void print(String s) {
//        System.out.println(s);
    }
}
